(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@codemirror_state_dist_index_beabeda8.js",
  "static/chunks/node_modules_@codemirror_view_dist_index_1e1dfd1c.js",
  "static/chunks/node_modules_a6d18651._.js",
  "static/chunks/_b4b746b2._.js",
  "static/chunks/ui_RunButton_RunButton_module_7fac360d.css"
],
    source: "dynamic"
});
